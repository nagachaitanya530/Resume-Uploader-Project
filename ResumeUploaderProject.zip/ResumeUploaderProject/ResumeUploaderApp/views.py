from django.shortcuts import render
from ResumeUploaderApp.forms import ResumeForm
from django.contrib import messages
from django.views import View
from ResumeUploaderApp.models import Resume

# Create your views here.

class HomeView(View):
    def get(self, request):
        form = ResumeForm()
        candidates = Resume.objects.all()
        return render(request,'home.html',{'form':form,'candidates':candidates})

    def post(self,request):
        form = ResumeForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request,"your Profile has been Posted Successfully")
            return render(request,'home.html',{'form':form})

class CandidateView(View):
    def get(self,request,pk):
        candidate = Resume.objects.get(pk=pk)
        return render(request,'candidate.html',{'candidate':candidate})

